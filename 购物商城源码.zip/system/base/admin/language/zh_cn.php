<?php

#[后台主菜单]

$strAdminMenu1="首页";
$strAdminSet="设置";

$strPlusEnter="排版";
$strPlusExit="访问";
$strAdminExit="退出";

$strAdminLogout="退出管理系统";



$strAdminTitle="网站管理系统";
$strDesktopDomain="授权域名：";
$strDesktopSoftName="软件名称：";
$strDesktopUser="授权用户：";
$strDesktopUpdate="软件升级：";
$strDesktopVer="软件版本：";
$strDesktopRelease="更新时间：";
$strDesktopAuth="软件授权：";

$strShotcut="事务受理";
$strShotcutMember="待审核会员";
$strShotcutNews="未审核内容";
$strShotcutFeedback1="未查阅反馈";
$strShotcutFeedback2="未回复反馈";
$strAdminNoright="没有管理权限";



#[翻页]

$strPagesUp="上一页";
$strPagesDown="下一页";
$strPagesStart="首页";
$strPagesEnd="尾页";
$strPagesDi="第";
$strPagesYe="页";


$strPagesTotalStart="共 ";
$strPagesTotalEnd=" 条";
$strPagesMeiye="每页 ";
$strPagesYeci="页次";
$strPagesNowListFrom="";
$strPagesNowListTo=" 条";


#[通用]

$strDelete="删除";
$strModify="修改";
$strConfirm="确定";
$strCancel="取消";
$strXuhao="序号";
$strBack="返回";
$strModifySet="修改设置";
$strCat="类别";
$strTopCat="顶级分类";
$strCatAdd="添加分类";
$strCatTblTitle="类别维护";
$strConTopCat="顶级类别";
$strDeleteConfirm="确实要删除吗？";
$strSearchTitle="搜索";
$strReflesh="刷新";
$strSubmit="提交";
$strWindowClose="关闭";
$strFbtime="发布时间";
$strUptime="更新时间";
$strYear="年";
$strMonth="月";
$strDay="日";
$strHour="时";
$strMin="分";
$strSec="秒";
$strAsc="顺排";
$strDesc="倒排";
$strDefault="默认";
$strBlank="新窗口";
$strSelf="原窗口";
$strDiySet="自定义";
$strAutoSet="按比例";
$strReDefault="恢复默认";
$strShow="显示";
$strHidden="隐藏";
$strModifyOk="修改成功";
$strAddOk="添加成功";
$strYes="是";
$strNo="否";
$strAllow="允许";
$strDenny="禁止";
$strAuto="自动";
$strUrl="链接网址";
$strWei="位";
$strGuest="游客";
$strQuery="查询";
$strUse="启用";
$strPrice="价格";
$strFuncIntro="功能介绍";
$strLook="查看";
$strFeedBack="回复";
$strSecure="权限";
$strSecure1="阅读权限";
$strNolimit="不限";
$strCanle="取消";
$strlimit="限制";
$strDelAll="群删";
$strDeleteAll="批量删除";
$strSelAll="全选";
$strEdit="编辑";
$strDo="操作";
$strSel="选择";
$strAll="全部";
$strRootDir="主目录";
$strNumber="编号";
$strAdd="新增";
$strWidth="宽度";
$strHeight="高度";
$strClose="关闭";
$strOpen="打开";
$strWord="字";
$strDeleteAcc="删除帐户";

#[翻页]

$strPagesTotalStart="共 ";
$strPagesTotalEnd=" 条";
$strPagesNowPagesFrom="显示第 ";
$strPagesNowPagesTo=" 页";
$strPagesNowListFrom="";
$strPagesNowListTo=" 条";

#[图片上传]

$strUploadNotice1="请选择需上传的图片文件";
$strUploadNotice2="图片文件请勿超过2M";
$strUploadNotice3="只能上传JPG、GIF、PNG图片和FLASH文件";
$strUploadNotice4="只能上传GIF,JPG或PNG图片格式";


$strDownNotice9="请选择需上传的文件!";
$strDownNotice11="不能上传此类文件!";



#[插件管理]

$strPlusSet="插件管理";
$strPlusPageSet="页面设置";
$strPlusReg="插件管理";
$strPlusAdd="插件注册";
$strPlusName="插件名称";
$strPlusLable="插件标签";
$strPlusType="适用模块";
$strPlusMove="是否可换";
$strPlusSel="可设项目";
$strPlusSys="不可更换";
$strPlusLocat="适用页面";
$strPlusDiy="可以更换";
$strPlusFormType="插件来源";
$strPlusNews="文章频道";

$strPsetMod="页面参数设置";
$strPlusMod="页面插件设置";
$strPlusTempNotice="模版页不存在";
$strPlusSetup="插件设置";
$strPlusAddGlobal1="插入到全站同一位置";
$strPlusGlobal1="全站同名插件共享设置";
$strPlusGlobalDel="删除全站同名插件";
$strPSetGlobal="复制设置到全站";


$strPlusSelType="选择插件";
$strPlusSelSetup="设置";
$strPset="页面参数设置";
$strTempFile="模版文件";
$strTempDef="默认风格";
$strTemplates="模版";
$strTempFileDef="默认模版";


$strPlusZone1="插件风格设置";
$strPlusZone2="插件边框设置";
$strPlusZone3="插件参数设置";
$strPlusZone4="选择素材图片";
$strPlustempname="风格样式";
$strPlusshownums="显示条数";
$strPlusord="排序参数";
$strPlussc="排序方式";
$strPlussc1="倒序排列";
$strPlussc2="顺序排列";
$strPlusonlycat="显示范围";
$strPluscutword="截取标题字数";
$strPlustarget="窗口打开方式";
$strPluscatid="显示类别范围";
$strPlusProjid="显示专题范围";
$strPlusProjDef="不限制专题范围";
$strPluscatidDef="全部类别或按所在页面自动选择类别";
$strPlusbody="编辑内容";
$strPlusBkTitle="版块标题";
$strPlusPic="上传图片";
$strPlusAttach="上传文件";
$strPlusWord="自定文字";
$strPlusText="文字内容";
$strPlusCode="插入代码";
$strPlusPicLink="图片链接";
$strPlusLink="链接网址";
$strPlusMovi="来源网址";
$strPlusSetGlobal="全站共享";
$strPlusGroupid="选择分组";
$strPlusCutBody="截取内容字数";
$strPlusBorder0="不显示外框";
$strPlusBorderTemp="外框模板";
$strPlusBorderColor="外框颜色";
$strPlusPadding="内容边距";
$strPlusBG="背景颜色";
$strPlusMoreLink="更多链接";
$strPlusNoBorder="无边框";
$strPlusBar="显示标题栏";
$strPlusBarGg="标题栏背景";
$strPlusBarColor="标题文字色";
$strPlusTitle="插件标题";
$strPlusSelColor="请选择颜色";
$strPlusShowTj="显示推荐";
$strPlusShowTj0="不限制";
$strPlusShowTj1="只显示推荐内容";
$strBorderNotExist="外框模版不存在";
$strBorderType1="选择边框模版";
$strBorderType2="自定义边框";
$strPlusBarHidden="隐藏边框和背景";

$strPlusWei="插件定位";
$strPlusSize="插件尺寸";
$strPlusTop="顶距左距";

$strPlusBP="边框宽度";
$strPlusBorderStyle="边框样式";
$strPlusBorderColor="边框颜色";
$strPlusAddTo="插入到";
$strPlusNoHidden="显示本插件";
$strPlusFlow="内容溢出";
$strPlusFlow1="内容溢出时隐藏";
$strPlusFlow2="内容溢出时自动增加高度";
$strPlusBodyZone1="顶部区域";
$strPlusBodyZone2="中间区域";
$strPlusBodyZone3="底部区域";
$strPlusBodyZone0="外侧区域";
$strPlusGroup="选择分组";

$strPlusPicW="缩图宽度";
$strPlusPicH="缩图高度";
$strPlusFitType="适应方式";
$strPlusFitType1="等比例填充图片区域";
$strPlusFitType2="等比例缩放图片";
$strPlusFitType3="变形拉伸图片";
$strPlusFitNtc="备注：同一页面中各图片插件的适应方式必须相同";

$strPlusBs1="实线";
$strPlusBs2="虚线";
$strPlusBs3="点状";
$strPlusBs4="双线";


$strPlusMore="显示更多";
$strPlusTag="匹配标签";

$strPlusIndexPage="首页";

$strPlusNotice1="请输入插件名称";
$strPlusNotice2="插件注册成功，请设置插件参数";
$strPlusNotice3="同模版页同样标签的插件已经存在";
$strPlusNotice4="缺少参数";
$strPlusNotice5="模版文件不存在";
$strPlusNotice6="当前页面已经存在同名插件";

$strPlusNotice7="请输入插件标签";
$strPlusNotice8="请输入插件位置";

$strPlusLab="标签";
$strPlusLableNo="被控插件编号：";
$strPlusLablerolll="点击切换";
$strPlusLableroll2="悬停切换";
$strPlusLableroll3="自动播放";



#[升级更新]

$strUpdate="软件升级更新";
$strUpdateDate="发布日期";
$strUpdateMsg="更新内容";
$strUpdateUped="已上传";
$strUpdateOk="已更新";
$strUpdateDo="安装更新";
$strUpdateInstall="安装更新";
$strUpdatews="尚未上传";
$strUpdateed="完成更新";
$strUpdateNTC="升级服务器连接失败,请稍后再试";
$strUpdateNTC1="已完成更新";



#[系统设置菜单]
$strSetMenu0="管理系统首页";
$strSetMenu1="网站参数设置";
$strSetMenu2="管理菜单设置";
$strSetMenu3="修改管理密码";
$strSetMenu4="新增管理账户";
$strSetMenu5="管理帐户维护";
$strSetMenu6="模块插件管理";
$strSetMenu8="软件升级更新";
$strSetMenu11="底部信息编辑";
$strSetMenu12="自定内容编辑";




#[参数设置]
$strConfigOk="已保存设置";
$strSiteName="网站名称";
$strSiteHttp="网站网址";
$strSiteEmail="服务邮箱";
$strEmailSet="邮件转发环境设置";
$strEmailSys="邮件转发方式";
$strEmailSys0="不发送系统邮件";
$strEmailSys1="使用LINUX/UNIX内置邮件转发";
$strEmailSys2="使用外部SMTP邮件服务器转发";
$strEmailSmtp="SMTP服务器";
$strEmailUser="SMTP邮箱用户名";
$strEmailPass="SMTP邮箱密码";
$strEmailRePass="重设密码";
$strEmailBox="对应SMTP邮箱";
$strEmailCheck="发信身份验证";
$strConfigName="参数名称";
$strConfigSet="设置";

#[后台菜单设置]
$strAdminMenuNtc1="已存在下级菜单，不可删除";
$strAdminMenuNtc2="请输入菜单名称";
$strAdminMenuName="菜单名称";
$strAdminMenuAdd="新增菜单";
$strAdminsMenuAdd="新增二级菜单";
$strAdminMenuXuhao="序号";
$strAdminMenu="管理菜单名称";
$strAdminMenuUrl="功能链接";


#[管理权限设置]

$strPasswdNTC1="您两次输入的密码不同";
$strPasswdNTC2="密码修改成功,请重新登录";
$strPasswdNTC3="重新登录";
$strPasswdNTC4="密码修改成功";
$strPasswdNTC5="用户名或原密码输入错误";

$strPasswdModiUser="用 户 名";
$strPasswdModiOld="原 密 码";
$strPasswdModiNew="新 密 码";
$strPasswdModiRe="重复密码";

$strAuthNew="新增管理帐户";


$strAuthNTC1="同样的管理员用户名已经存在";
$strAuthNTC2="管理员添加成功";
$strAuthNTC3="请填写用户名和密码";


$strAuthUser="管理员账号";
$strAuthPass="管理员密码";
$strAuthSet="设置管理权限";
$strAuthJob="管理员职务";
$strAuthJobId="管理员工号";

$strAuth="授权";
$strAuthGroup="所属模块";
$strAuthName="权限描述";
$strAuthUserName="管理员姓名";

$strAuthModi="修改管理权限";
$strAuthModify="修改权限";
$strAuthModifyOk="权限修改成功";
$strAuthModi2="修改姓名职务";

$strAuthDelNTC1="系统管理员帐户不能删除,只能修改密码";


#[模块插件管理]
$strColName="模块名称";
$strColSName="简称";
$strColType="模块代码";
$strColIU="模块卸载";
$strColInstall="安装模块";
$strColUnInstall="模块卸载";
$strGetCollist="查询未安装模块";
$strColPlusGl="插件管理";
$strColTempGl="模版管理";
$strColPlusNum="插件数量";
$strTempNum="模版";
$strTempName="模版名称";
$strTempAdd="添加模版";
$strPlusOutput="导出插件";
$strPlusOutput1="导出";
$strPlusInput="导入插件";
$strPlusBorderGl="边框管理";
$strPlusBorderType="边框类型";
$strPlusBorderType1="插件边框";
$strPlusBorderType2="标签边框";
$strPlusBorderNo="边框编号";
$strPlusBorderName="边框描述";
$strPlusBorderAdd="添加边框";
$strPlusBorderSelColor="可选颜色";
$strPlusBorderNoColor="不可选颜色";


#[自定义内容编辑]
$strDiyBottomEdit="底部信息编辑";
$strDiyBottomEdit2="同时修改全站底部信息";
$strDiyBottomNotice1="网站中尚未插入任何[底部信息编辑区]插件";
$strDiyBottomNotice3="底部信息请不要超过65KB";
$strDiyBottomNotice4="全站底部信息已更新";
$strDiyBottomNotice5="当前页底部信息已更新";

$strDiyEdit="自定内容编辑";
$strDiyEditNotice1="网站中尚未插入任何[HTML编辑区]插件";
$strDiyNotice2="同时修改";
$strDiyNotice21="个与此内容相同的编辑区";
$strDiyNotice3="内容请不要超过65KB";
$strDiyNotice5="内容更新成功";

?>